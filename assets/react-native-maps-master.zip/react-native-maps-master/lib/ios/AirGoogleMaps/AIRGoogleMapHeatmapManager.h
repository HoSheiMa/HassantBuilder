//
//  AIRGoogleMapHeatmapManager.h
//
//  Created by David Cako on 29 April 2018.
//

#import <React/RCTViewManager.h>

@interface AIRGoogleMapHeatmapManager : RCTViewManager

@end