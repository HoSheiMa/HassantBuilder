//
//  AIRGoogleMapCalloutSubviewManager.h
//  AirMaps
//
//  Created by Denis Oblogin on 10/8/18.
//
//

#ifdef HAVE_GOOGLE_MAPS

#import <React/RCTViewManager.h>

@interface AIRGoogleMapCalloutSubviewManager : RCTViewManager

@end

#endif
