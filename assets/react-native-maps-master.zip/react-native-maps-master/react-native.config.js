module.exports = {
  dependency: {
    platforms: {
      android: {
        sourceDir: './lib/android',
      },
    },
  },
};
