export const baseTextStyles = {
  fontWeight: '700',
  letterSpacing: -0.5
};
