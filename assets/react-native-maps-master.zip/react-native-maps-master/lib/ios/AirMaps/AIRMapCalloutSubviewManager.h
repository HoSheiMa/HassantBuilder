//
//  AIRMapCalloutSubviewManager.h
//  AirMaps
//
//  Created by Denis Oblogin on 10/8/18.
//
//

#import <React/RCTViewManager.h>

@interface AIRMapCalloutSubviewManager : RCTViewManager

@end

