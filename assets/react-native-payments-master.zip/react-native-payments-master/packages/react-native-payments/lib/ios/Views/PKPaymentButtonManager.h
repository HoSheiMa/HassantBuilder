//
//  ApplePayPaymentButtonManager.h
//  ReactNativePaymentsExample
//
//  Created by Andrej on 15/05/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import <React/RCTViewManager.h>

@interface PKPaymentButtonManager : RCTViewManager

@end
