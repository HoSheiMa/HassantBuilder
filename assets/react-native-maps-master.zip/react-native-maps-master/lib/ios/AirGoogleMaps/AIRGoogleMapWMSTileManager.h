//
//  AIRGoogleMapWMSTileManager.h
//  AirMaps
//
//  Created by nizam on 10/28/18.
//  Copyright © 2018. All rights reserved.
//

#ifdef HAVE_GOOGLE_MAPS

#import <Foundation/Foundation.h>
#import <React/RCTViewManager.h>

@interface AIRGoogleMapWMSTileManager : RCTViewManager
@end

#endif
