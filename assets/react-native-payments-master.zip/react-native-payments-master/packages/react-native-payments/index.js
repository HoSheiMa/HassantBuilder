module.exports = require('./lib/js');
